import React from 'react'
import ChatWidget from '../components/Chat/ChatWidget';

const ChatView = () => {
    return (
        <ChatWidget />
    )
}

export default ChatView